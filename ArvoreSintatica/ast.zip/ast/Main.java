package ast;

import java.util.ArrayList;

public class Main {
    public ArrayList<VarDecl> vars;
    public ArrayList<Comando> coms;

    public Main(ArrayList<VarDecl> vars, ArrayList<Comando> coms) {
        this.vars = vars;
        this.coms = coms;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (VarDecl var : vars) {
            sb.append(var.toString());
        }
        for (Comando com : coms) {
            sb.append(com.toString());
        }
        return sb.toString();
    }
}
