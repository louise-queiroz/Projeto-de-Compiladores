package ast;

public class EFalse extends Exp {
    public EFalse() {
    }

    @Override
    public String toString() {
        return "false";
    }
}
