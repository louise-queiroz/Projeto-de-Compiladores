package ast;


public class Comando{}
