package ast;

public class ParamFormalFun {
    public String var;
    public String type;

    public ParamFormalFun(String var, String type) {
        this.var = var;
        this.type = type;
    }

    @Override
    public String toString() {
        return type + " " + var;
    }
}
