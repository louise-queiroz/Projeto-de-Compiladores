package ast;

public class ETrue extends Exp {
    public ETrue() {
    }

    @Override
    public String toString() {
        return "true";
    }
}
